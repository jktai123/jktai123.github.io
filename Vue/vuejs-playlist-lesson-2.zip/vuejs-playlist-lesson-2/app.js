new Vue({
    el: '#vue-app',
    data: {
        name: 'Shaun'
    }
});
