全球地震視覺化
--------------------

for http://blog.infographics.tw/2015/05/d3js-tutorial-global-earthquake-visualization/
