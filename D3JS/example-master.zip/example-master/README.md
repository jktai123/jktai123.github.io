example files for blog.infographics.tw
